package com.example.riegoiot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    NavegacionApp()
                }
            }
        }
    }
}

// Funciones auxiliares para registrar fecha/hora en el historial Cloud
fun obtenerHoraActual(): String {
    val formato = SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault())
    return formato.format(Date())
}

fun registrarEventoHistorial(mensaje: String) {
    val db = FirebaseDatabase.getInstance().reference
    db.child("historial").push().setValue("${obtenerHoraActual()} - $mensaje")
}

// Componente visual para mostrar estado de red y respaldo OT (Fail-Safe)
@Composable
fun IndicadorConexionCloud(conectado: Boolean) {
    val colorFondo = if (conectado) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)
    val colorTexto = if (conectado) Color(0xFF2E7D32) else Color(0xFFC62828)
    val textoEstado = if (conectado) {
        "En línea: Firebase Cloud (Wi-Fi)"
    } else {
        "Sin conexión Cloud: Fail-Safe local activo en Arduino"
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = colorFondo),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = textoEstado,
            color = colorTexto,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(12.dp)
        )
    }
}

// 1. NAVEGACIÓN PRINCIPAL (Rutas entre pantallas)
@Composable
fun NavegacionApp() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "login") {
        composable("login") {
            PantallaLogin(navController)
        }
        composable("dueno") {
            PantallaDueno(navController)
        }
        composable("admin") {
            PantallaAdmin(navController)
        }
    }
}

// 2. PANTALLA DE LOGIN (Firebase Authentication - ISO 27400 / HTTPS + Hash)
@Composable
fun PantallaLogin(navController: NavController) {
    val auth = remember { FirebaseAuth.getInstance() }

    var correo by rememberSaveable { mutableStateOf("") }
    var clave by rememberSaveable { mutableStateOf("") }
    var mensajeError by rememberSaveable { mutableStateOf("") }
    var cargando by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Sistema de Riego IoT",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = "Acceso Seguro Cloud (Wi-Fi)", color = Color.Gray)

        Spacer(modifier = Modifier.height(24.dp))

        TextField(
            value = correo,
            onValueChange = { correo = it },
            label = { Text("Correo electrónico") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        TextField(
            value = clave,
            onValueChange = { clave = it },
            label = { Text("Contraseña") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (mensajeError.isNotEmpty()) {
            Text(text = mensajeError, color = Color.Red)
            Spacer(modifier = Modifier.height(8.dp))
        }

        Button(
            onClick = {
                val correoLimpio = correo.trim().lowercase()
                if (correoLimpio.isEmpty() || clave.isEmpty()) {
                    mensajeError = "Completa correo y contraseña."
                    return@Button
                }

                cargando = true
                mensajeError = ""

                // Autenticación segura en Firebase (contraseña con hash y tráfico HTTPS/TLS)
                auth.signInWithEmailAndPassword(correoLimpio, clave)
                    .addOnCompleteListener { tarea ->
                        cargando = false
                        if (tarea.isSuccessful) {
                            val destino = if (correoLimpio.startsWith("admin")) "admin" else "dueno"
                            navController.navigate(destino) {
                                popUpTo("login") { inclusive = true }
                            }
                        } else {
                            mensajeError = "Credenciales incorrectas o sin conexión."
                        }
                    }
            },
            enabled = !cargando,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (cargando) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            } else {
                Text("Ingresar")
            }
        }
    }
}

// 3. PANTALLA DEL DUEÑO (Monitoreo en vivo + Control de Bomba en Firebase)
@Composable
fun PantallaDueno(navController: NavController) {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseDatabase.getInstance().reference }
    val refConexion = remember { FirebaseDatabase.getInstance().getReference(".info/connected") }

    var temperatura by rememberSaveable { mutableIntStateOf(22) }
    var humedadAire by rememberSaveable { mutableIntStateOf(55) }
    var humedadSuelo by rememberSaveable { mutableIntStateOf(250) }
    var bombaActiva by rememberSaveable { mutableStateOf(false) }
    var conectadoCloud by remember { mutableStateOf(false) }

    // Escucha en tiempo real de Firebase (sensores, bomba y estado de conexión)
    DisposableEffect(Unit) {
        val listenerConexion = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                conectadoCloud = snapshot.getValue(Boolean::class.java) ?: false
            }
            override fun onCancelled(error: DatabaseError) {}
        }

        val listenerSensores = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) {
                    // Crea los nodos iniciales en Firebase la primera vez
                    val iniciales = mapOf<String, Any>(
                        "temperatura" to 22,
                        "humedadAire" to 55,
                        "humedadSuelo" to 250
                    )
                    db.child("sensores").setValue(iniciales)
                } else {
                    temperatura = snapshot.child("temperatura").getValue(Long::class.java)?.toInt() ?: 22
                    humedadAire = snapshot.child("humedadAire").getValue(Long::class.java)?.toInt() ?: 55
                    humedadSuelo = snapshot.child("humedadSuelo").getValue(Long::class.java)?.toInt() ?: 250
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        }

        val listenerBomba = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) {
                    db.child("actuadores/bomba").setValue(false)
                } else {
                    bombaActiva = snapshot.getValue(Boolean::class.java) ?: false
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        }

        refConexion.addValueEventListener(listenerConexion)
        db.child("sensores").addValueEventListener(listenerSensores)
        db.child("actuadores/bomba").addValueEventListener(listenerBomba)

        onDispose {
            refConexion.removeEventListener(listenerConexion)
            db.child("sensores").removeEventListener(listenerSensores)
            db.child("actuadores/bomba").removeEventListener(listenerBomba)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Panel del Dueño",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))
        IndicadorConexionCloud(conectado = conectadoCloud)
        Spacer(modifier = Modifier.height(20.dp))

        // Tarjeta de Monitoreo de Sensores
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "Clima Ambiental (DHT11)", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Temperatura: $temperatura °C")
                    Text(text = "Humedad Aire: $humedadAire %")
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(16.dp))

                Text(text = "Sensor de Suelo (Keyestudio)", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "Lectura actual: $humedadSuelo")

                if (humedadSuelo < 300) {
                    Text(
                        text = "Estado: TIERRA SECA - Requiere riego",
                        color = Color.Red,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Text(
                        text = "Estado: ÓPTIMO",
                        color = Color(0xFF2E7D32),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Control de Actuador conectado a Firebase (el Arduino/ESP leerá este nodo)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = if (bombaActiva) "Bomba: REGANDO..." else "Bomba: APAGADA",
                fontWeight = FontWeight.Bold
            )
            Switch(
                checked = bombaActiva,
                onCheckedChange = { nuevoEstado ->
                    bombaActiva = nuevoEstado
                    db.child("actuadores/bomba").setValue(nuevoEstado)
                    val accion = if (nuevoEstado) "Bomba ENCENDIDA" else "Bomba APAGADA"
                    registrarEventoHistorial("$accion por Dueño (Suelo: $humedadSuelo)")
                }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Botón para simular el envío de sensores a Firebase antes de conectar el Arduino físico
        OutlinedButton(
            onClick = {
                val nuevoSuelo = if (humedadSuelo < 300) 520 else 210
                val nuevaTemp = if (humedadSuelo < 300) 21 else 26
                val datosSimulados = mapOf<String, Any>(
                    "temperatura" to nuevaTemp,
                    "humedadSuelo" to nuevoSuelo
                )
                db.child("sensores").updateChildren(datosSimulados)
                registrarEventoHistorial("Lectura sensor - Temp: ${nuevaTemp}°C | Suelo: $nuevoSuelo")
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Simular lectura de sensor en Cloud")
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                auth.signOut()
                navController.navigate("login") {
                    popUpTo("dueno") { inclusive = true }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Cerrar Sesión")
        }
    }
}

// 4. PANTALLA DEL ADMINISTRADOR (Supervisión e Historial en tiempo real)
@Composable
fun PantallaAdmin(navController: NavController) {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseDatabase.getInstance().reference }
    val refConexion = remember { FirebaseDatabase.getInstance().getReference(".info/connected") }

    var historialCloud by remember { mutableStateOf(listOf<String>()) }
    var estadoBomba by remember { mutableStateOf(false) }
    var conectadoCloud by remember { mutableStateOf(false) }

    // Escucha en tiempo real del historial y estado de la bomba (solo lectura)
    DisposableEffect(Unit) {
        val listenerConexion = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                conectadoCloud = snapshot.getValue(Boolean::class.java) ?: false
            }
            override fun onCancelled(error: DatabaseError) {}
        }

        val listenerBomba = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                estadoBomba = snapshot.getValue(Boolean::class.java) ?: false
            }
            override fun onCancelled(error: DatabaseError) {}
        }

        val listenerHistorial = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val listaTemporal = mutableListOf<String>()
                for (hijo in snapshot.children) {
                    hijo.getValue(String::class.java)?.let { listaTemporal.add(it) }
                }
                // Orden inverso para mostrar el evento más reciente arriba
                historialCloud = listaTemporal.reversed()
            }
            override fun onCancelled(error: DatabaseError) {}
        }

        refConexion.addValueEventListener(listenerConexion)
        db.child("actuadores/bomba").addValueEventListener(listenerBomba)
        db.child("historial").addValueEventListener(listenerHistorial)

        onDispose {
            refConexion.removeEventListener(listenerConexion)
            db.child("actuadores/bomba").removeEventListener(listenerBomba)
            db.child("historial").removeEventListener(listenerHistorial)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text(
            text = "Panel Administrador",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        IndicadorConexionCloud(conectado = conectadoCloud)
        Spacer(modifier = Modifier.height(12.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Estado de bomba: ${if (estadoBomba) "REGANDO" else "APAGADA"} (Solo lectura)",
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(14.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(text = "Historial en Tiempo Real (Cloud)", fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        if (historialCloud.isEmpty()) {
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Sin registros aún. Los eventos aparecerán aquí en tiempo real.",
                    color = Color.Gray
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(historialCloud) { registro ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = registro,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                auth.signOut()
                navController.navigate("login") {
                    popUpTo("admin") { inclusive = true }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Cerrar Sesión")
        }
    }
}